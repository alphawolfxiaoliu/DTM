#include"algebra.h"
#include"uvde.h"
#include"mioutils.h"
#include"test.h"
#include<iostream>
#include<fstream>
#include<string>
#include<cstdio>

using namespace std;

/*
	Sougou�������Խ������������Ϊ0.02ʱ�����Էǳ���Ĵﵽ����
	-��̬����ģ�ͣ�static SONMFSR��
*/
void main_1(){
	string datafiles[] = {
		"20News/TFIDF+20NEWS+CLEAR5.txt"
	};
	// �洢ģ�ͽ��·��
	string dir = "20News/ResultStatic/19/";
	// lamadas��Ӧģ��ϡ���ԣ�elpsions��Ӧģ��������;lamadas��elpsionsһһ��Ӧ����ͬ��ϲ�����Ӧ��ͬ��ģ�ͣ�
	//double	lamadas[] = { 0.1, 0.1, 0.0, 0.0 };
	//double elpsions[] = { 0.0, 0.7, 0.0, 1.0 };  // updateU_saprse �� updateU �����汾��ǰ���ǸĽ���sparse on U, ������orthogonal on U

	// (1) 0.001 0.005 (2)0.01 0.005 (3)0.05 0.005 (4)0.02 0.01 (6) 0.02 0.05 (7)0.02 0.1 (8)0.02 0.2 (9)0.03 0.2
	// (10) 0.03 0.3 (11) 0.03 0.01 (12) 0.04 0.007 (13)0.04 0.001 (14) 0.002 0.006 (15-00-NMF)0 0 (16-01-Sparse)0.02 0.000 
	// (17-0-ONMF) 0.000 0.7 (18)0.01 0.006 (19)0.02 0.3 dropout
	double	lamadas[] = { 0.1, 0.02, 0.0, 0.0 };
	double elpsions[] = { 0.0, 0.3, 0.0, 1.0 };

	double	step[]	= {0.02}; //
	int	topics[]= {20, 40, 60, 80, 100};

	cout << "lamdadas:" << lamadas[1] << endl;
	cout << "elpsions:" << elpsions[1] << endl;

	char  savefile[200];
	matric2D * pData = readFileSparse(datafiles[0]);
	//lamda
	for (int parameter = 1; parameter < 2; parameter++){
		//topics
		for (int t = 0; t < 5; t++){
			//step
			for (int s = 0; s < 1; s++){ 
				int K = topics[t];
				uv_decompose * pde = new uv_decompose(pData->matric, pData->x_max, pData->y_max, K);
				pde->pU->random_init(true);
				pde->pV->random_init(true);
				//����
				pde->s = step[s];
				pde->lambda = lamadas[parameter];
				pde->epsilon = elpsions[parameter];
				pde->d_loop_max = 150;
				pde->u_loop_max = 100;
				pde->v_loop_max = 100;
				pde->u_eps = 5e-5;
				pde->v_eps = 5e-5;
				//sprintf(savefile, "20News/Result/L,topic=%d,e=%.1lf,l=%.5lf,s=%.5lf.log", K, pde->epsilon, pde->lambda, pde->s);
				sprintf(savefile, "%sL,topic=%d,e=%.3lf,l=%.5lf,s=%.5lf.log", dir.c_str(), K, pde->epsilon, pde->lambda, pde->s);
				pde->log_file_name = savefile;
				sprintf(savefile, "%sU,topic=%d,e=%.3lf,l=%.5lf,s=%.5lf", dir.c_str(), K, pde->epsilon, pde->lambda, pde->s);
				pde->u_file_name = savefile;
				sprintf(savefile, "%sV,topic=%d,e=%.3lf,l=%.5lf,s=%.5lf", dir.c_str(), K, pde->epsilon, pde->lambda, pde->s);
				pde->v_file_name = savefile;
				pde->saveIter = 200;
				pde->decompose();
				
				//�洢���ս��
				sprintf(savefile, "%sU,topic=%d,e=%.3lf,l=%.5lf,s=%.5lf_fin.txt", dir.c_str(), K, pde->epsilon, pde->lambda, pde->s);
				saveFileSparse(pde->pU, savefile);
				sprintf(savefile, "%sV,topic=%d,e=%.3lf,l=%.5lf,s=%.5lf_fin.txt", dir.c_str(), K, pde->epsilon, pde->lambda, pde->s);
				saveFileSparse(pde->pV, savefile);
				delete pde;
			}
		}
	}
	delete pData;
}