#include"algebra.h"
#include"uvde.h"
#include"mioutils.h"
#include<iostream>
#include<fstream>
#include<string>
#include<cstdio>

using namespace std;

#ifndef _TEST_1_
#define _TEST_1_

void test();

#endif