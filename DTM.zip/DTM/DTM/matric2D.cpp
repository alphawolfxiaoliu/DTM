#include"matric2D.h"

matric2D::matric2D(const int x,const int y){
	this->x_max = x;
	this->y_max = y;
	matric = new double*[x];
	for(int i=0;i<x_max;++i){
		matric[i] = new double[y];
	}
	//�����ʼ��
	for(int i=0;i<this->x_max;++i){
		for(int j=0;j<this->y_max;++j){
			this->matric[i][j] = 0.0;
		}
	}
}
matric2D::~matric2D(){
	for(int i=0;i<this->x_max;i++){
		delete[] matric[i];
	}
	delete[] matric;
}
void matric2D::set(const int x,const int y,const double value){
	if(x<0||x>=this->x_max
		||y<0||y>=this->y_max){
		cout<<"����Խ��"<<endl;
		return ;
	}
	this->matric[x][y] = value;
}
double matric2D::get(const int x,const int y){
	if(x<0||x>=this->x_max
		||y<0||y>=this->y_max){
		cout<<"����Խ��"<<endl;
		return -1;
	}
	return this->matric[x][y];
}
void matric2D::random_init(bool normalization){
	srand(time(0));
	
	for(int i=0;i<this->x_max;++i){
		for(int j=0;j<this->y_max;++j){
			this->set(i,j,rand()%10+1);
			//this->matric[i][j] = rand()%10+1;
		}
	}
	if(normalization)
		this->normalization();
}
void matric2D::normalization(){
	int core = omp_get_num_procs();
	#pragma omp parallel for num_threads(core)
	for(int j=0;j<this->y_max;++j){
		double value = 0.0;
		for(int i=0;i<this->x_max;++i){
			value += pow(this->get(i,j),2);
		}
		value = sqrt(value);
		if(value>0){
			for(int i=0;i<this->x_max;++i){
				this->set(i,j,this->get(i,j)/value);
			}
		}
	}
}
//��ӡ���ܲ���
void matric2D::print(){
	cout<<"x-dim:"<<this->x_max<<"\ty-dim:"<<this->y_max<<endl;
	for(int i=0;i<this->x_max;++i){
		for(int j=0;j<this->y_max;++j){
			cout<<setiosflags(ios::fixed)<<setprecision(10)<<this->get(i,j)<<" ";
		}
		cout<<endl;
	}
}
matric2D * matric2D::get_copy(){
	matric2D * pm = new matric2D(this->x_max,this->y_max);
	
	int core = omp_get_num_procs();
	#pragma omp parallel for num_threads(core)
	for(int i=0;i<pm->x_max;++i){
		for(int j=0;j<pm->y_max;++j){
			pm->set(i,j,this->get(i,j));
		}
	}
	return pm;
}

matric1D * matric2D::get_row(int row){
	if (row >= this->x_max){
		cout << "�кų�����Χ" << row << endl;
		return NULL;
	}
	matric1D * pR = new matric1D(this->y_max);
	for (int i = 0; i < this->y_max; i++){
		pR->matric[i] = this->matric[row][i];
	}
	return pR;
}

matric1D * matric2D::get_column(int column){
	if (column >= this->y_max){
		cout << "�кų�����Χ" << column << endl;
		return NULL;
	}
	matric1D * pC = new matric1D(this->x_max);
	for (int i = 0; i < this->x_max; i++){
		pC->matric[i] = this->matric[i][column];
	}
	return pC;
}
