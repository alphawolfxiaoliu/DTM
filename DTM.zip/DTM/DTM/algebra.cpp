#include"algebra.h"



matric1D * algebra::get_cloumn_vector(matric2D * pA,const int column){
	if(pA->y_max<=column){
		cout<<"����Ӧ��0~"<<pA->y_max-1<<"֮��"<<endl;
		return NULL;
	}
	matric1D * pm = new matric1D(pA->x_max);

	//int core = omp_get_num_procs();
	//#pragma omp parallel for num_threads(core)
	for(int i=0;i<pA->x_max;++i){
		pm->set(i,pA->get(i,column));
	}

	return pm;
}

matric2D * algebra::add(matric2D * pA,matric2D * pB){
	if(pA->x_max!=pB->x_max||pA->y_max!=pB->y_max){
		cout<<"������������һ!�޷���ӣ�\tA:"<<pA->x_max<<"x"<<pA->y_max<<"\tB:"<<pB->x_max<<"x"<<pB->y_max<<endl;
		return NULL;
	}

	matric2D * pm = new matric2D(pA->x_max,pA->y_max);

	int core = omp_get_num_procs();
	#pragma omp parallel for num_threads(core)
	for(int i=0;i<pm->x_max;++i){
		for(int j=0;j<pm->y_max;++j){
			pm->matric[i][j] =  pA->matric[i][j] + pB->matric[i][j];
		}
	}

	return pm;
}

matric2D * algebra::add_e(matric2D * pA,double value){
	matric2D * pm = pA->get_copy();

	int core = omp_get_num_procs();
	#pragma omp parallel for num_threads(core)
	for(int i=0;i<pm->x_max;++i){
		pm->matric[i][i] =  pm->matric[i][i] + value;
	}

	return pm;
}

matric2D * algebra::minus(matric2D * pA,matric2D * pB){
	if(pA->x_max!=pB->x_max||pA->y_max!=pB->y_max){
		cout<<"������������һ!�޷������\tA:"<<pA->x_max<<"x"<<pA->y_max<<"\tB:"<<pB->x_max<<"x"<<pB->y_max<<endl;
		return NULL;
	}

	matric2D * pm = new matric2D(pA->x_max,pA->y_max);

	int core = omp_get_num_procs();
	#pragma omp parallel for num_threads(core)
	for(int i=0;i<pm->x_max;++i){
		for(int j=0;j<pm->y_max;++j){
			pm->matric[i][j] =  pA->matric[i][j] - pB->matric[i][j];
		}
	}

	return pm;
}

matric2D * algebra::multi(matric2D * pA,matric2D * pB){
	return multi(pA, pB, 1);
}

matric2D * algebra::multi(matric2D * pA, matric2D * pB, double times){
	if (pA->y_max != pB->x_max){
		cout << "������������һ!�޷���ˣ�\tA:" << pA->x_max << "x" << pA->y_max << "\tB:" << pB->x_max << "x" << pB->y_max << endl;
		return NULL;
	}
	matric2D * pBt = algebra::transpose(pB);
	matric2D * pm = new matric2D(pA->x_max, pB->y_max);

	int core = omp_get_num_procs();
	#pragma omp parallel for num_threads(core)
	for (int i = 0; i<pm->x_max; ++i){
		for (int j = 0; j<pm->y_max; ++j){
			double value = 0.0;
			for (int k = 0; k<pA->y_max; k++){
				value += pA->matric[i][k] * pBt->matric[j][k];
			}
			pm->matric[i][j] = value*times;
		}
	}
	delete pBt;
	return pm;
}

matric2D * algebra::multi(matric2D * pA,const double times){
	matric2D * pm = new matric2D(pA->x_max,pA->y_max);	
	
	int core = omp_get_num_procs();
	#pragma omp parallel for num_threads(core)
	for(int i=0;i<pm->x_max;++i){
		for(int j=0;j<pm->y_max;++j){
			pm->matric[i][j] =  pA->matric[i][j] * times;
		}
	}
	return pm;
}

matric2D * algebra::transpose(matric2D * pA){
	matric2D * pm = new matric2D(pA->y_max,pA->x_max);	
	
	int core = omp_get_num_procs();
	#pragma omp parallel for num_threads(core)
	for(int i=0;i<pm->x_max;++i){
		for(int j=0;j<pm->y_max;++j){
			pm->matric[i][j] =  pA->matric[j][i];
		}
	}
	return pm;
}

matric2D * algebra::non_nagetive_map(matric2D * pA){
	matric2D * pm = new matric2D(pA->x_max,pA->y_max);	
	
	int core = omp_get_num_procs();
	#pragma omp parallel for num_threads(core)
	for(int i=0;i<pm->x_max;++i){
		for(int j=0;j<pm->y_max;++j){
			double value = pA->get(i,j);
			if(value>0){
				pm->matric[i][j] = value;
			}else{
				pm->matric[i][j] = 0;
			}

		}
	}
	return pm;
}
/*
	���зָ����
*/
void algebra::devide_row(matric2D * pA, matric2D * &pA1, matric2D * &pA2, int k1, int k2){
	//��ʼ��
	pA1 = new matric2D(k1, pA->y_max);
	pA2 = new matric2D(k2, pA->y_max);

	for (int i = 0; i < pA->x_max; i++){
		for (int j = 0; j < pA->y_max; j++){
			if (i < k1){
				pA1->matric[i][j] = pA->matric[i][j];
			}
			else{
				pA2->matric[i - k1][j] = pA->matric[i][j];
			}
		}
	}
}
/*
	���зָ����
*/
void algebra::devide_column(matric2D * pA, matric2D * &pA1, matric2D * &pA2, int k1, int k2){
	//��ʼ��
	pA1 = new matric2D(pA->x_max, k1);
	pA2 = new matric2D(pA->x_max, k2);

	for (int i = 0; i < pA->x_max; i++){
		for (int j = 0; j < pA->y_max; j++){
			if (j < k1){
				pA1->matric[i][j] = pA->matric[i][j];
			}
			else{
				pA2->matric[i][j - k1] = pA->matric[i][j];
			}
		}
	}
}
matric2D * algebra::merge_column(matric2D * pA1, matric2D * pA2){
	matric2D * pA = new matric2D(pA1->x_max, pA1->y_max + pA2->y_max);
	for (int i = 0; i < pA->x_max; i++){
		for (int j = 0; j < pA->y_max; j++){
			if (j < pA1->y_max){
				pA->matric[i][j] = pA1->matric[i][j];
			}
			else{
				pA->matric[i][j] = pA2->matric[i][j - pA1->y_max];
			}
		}
	}
	return pA;
}

double algebra::norm_1(matric2D * pA){
	double value = 0.0;

	int core = omp_get_num_procs();
	#pragma omp parallel for num_threads(core) reduction(+:value)
	for(int i=0;i<pA->x_max;++i){
		double max = 0.0;
		for(int j=0;j<pA->y_max;++j){
			if(max<abs(pA->get(i,j))){
				max = abs(pA->get(i,j));
			}
		}
		value+=max;
	}
	return value;
}

double algebra::norm_f(matric2D * pA){
	double value = 0.0;

	int core = omp_get_num_procs();
	#pragma omp parallel for num_threads(core) reduction(+:value)
	for(int i=0;i<pA->x_max;++i){
		for(int j=0;j<pA->y_max;++j){
			value+=pow(pA->get(i,j),2);
		}
	}
	return sqrt(value);
}

matric1D * algebra::add(matric1D * pA,matric1D * pB){
	if(pA->x_max!=pB->x_max){
		cout<<"������ģ��һ���޷����!\tA:"<<pA->x_max<<"\tB:"<<pB->x_max<<endl;
		return NULL;
	}
	matric1D * pm = new matric1D(pA->x_max);

	//int core = omp_get_num_procs();
	//#pragma omp parallel for num_threads(core)
	for(int i=0;i<pm->x_max;++i){
		pm->set(i,pA->get(i)+pB->get(i));
	}
	return pm;
}

matric1D * algebra::add_e(matric1D * pA,const double value){
	matric1D * pm = new matric1D(pA->x_max);

	//int core = omp_get_num_procs();
	//#pragma omp parallel for num_threads(core)
	for(int i=0;i<pm->x_max;++i){
		pm->set(i,pA->get(i)+value);
	}
	return pm;
}

matric1D * algebra::minus(matric1D * pA,matric1D * pB){
	if(pA->x_max!=pB->x_max){
		cout<<"������ģ��һ���޷����!\tA:"<<pA->x_max<<"\tB:"<<pB->x_max<<endl;
		return NULL;
	}
	matric1D * pm = new matric1D(pA->x_max);

	//int core = omp_get_num_procs();
	//#pragma omp parallel for num_threads(core)
	for(int i=0;i<pm->x_max;++i){
		pm->set(i,pA->get(i)-pB->get(i));
	}
	return pm;
}

double algebra::multi(matric1D * pA,matric1D * pB){
	if(pA->x_max!=pB->x_max){
		cout<<"������ģ��һ���޷����!\tA:"<<pA->x_max<<"\tB:"<<pB->x_max<<endl;
		return NULL;
	}
	double value = 0.0;

	//int core = omp_get_num_procs();
	//#pragma omp parallel for num_threads(core) reduction(+:value)
	for(int i=0;i<pA->x_max;++i){
		value+=pA->get(i)*pB->get(i);
	}

	return value;
}

matric1D * algebra::non_nagetive_map(matric1D * pA){
	matric1D * pm = new matric1D(pA->x_max);

	//int core = omp_get_num_procs();
	//#pragma omp parallel for num_threads(core)
	for(int i=0;i<pm->x_max;++i){
		double value = pA->get(i);
		if(value>0){
			pm->set(i,value);
		}else{
			pm->set(i,0.0);
		}
	}
	return pm;
}

double algebra::norm_1(matric1D * pA){
	double max = 0.0;
	for(int i=0;i<pA->x_max;++i){
		if(max<abs(pA->get(i))){
			max = abs(pA->get(i));
		}
	}
	return max;
}

double algebra::norm_2(matric1D * pA){
	double value = 0.0;

	//int core = omp_get_num_procs();
	//#pragma omp parallel for num_threads(core) reduction(+:value)
	for(int i=0;i<pA->x_max;i++){
		value+=pow(pA->get(i),2);
	}
	return sqrt(value);
}

//int cache_size = 512;
//int min_cache = 32;

//int find(int x){
//	int i = cache_size;
//	if (i > x - 1){
//		i = x - 1;
//	}
//	for (; i >= min_cache; i--){
//		if (x%i == 0){
//			return i;
//		}
//	}
//	if (i < min_cache){
//		return x;
//	}
//}

//matric2D * algebra::multi_s(matric2D * pA, matric2D * pB){
//	int ax = pA->x_max;
//	int ay = pA->y_max;
//	if (ax % 2 == 1)ax++;
//	if (ay % 2 == 1)ay++;
//	int bx = pB->x_max;
//	int by = pB->y_max;
//	if (bx % 2 == 1)bx++;
//	if (by % 2 == 1)by++;
//
//	matric2D * A = pA->get_copy(0, ax / 2, 0, ay / 2);
//	matric2D * B = pA->get_copy(0, ax / 2, ay / 2, ay);
//	matric2D * C = pA->get_copy(ax / 2, ax, 0, ay / 2);
//	matric2D * D = pA->get_copy(ax / 2, ax, ay / 2, ay);
//
//	matric2D * E = pB->get_copy(0, bx / 2, 0, by / 2);
//	matric2D * F = pB->get_copy(0, bx / 2, by / 2, by);
//	matric2D * G = pB->get_copy(bx / 2, bx, 0, by / 2);
//	matric2D * H = pB->get_copy(bx / 2, bx, by / 2, by);
//
//	matric2D * tmp1, *tmp2;
//	matric2D * p1, *p2, *p3, *p4, *p5, *p6, *p7;
//	
//	tmp1 = algebra::minus(F, H);
//	p1 = algebra::multi(A, tmp1);
//	delete tmp1;
//
//	tmp1 = algebra::add(A, B);
//	p2 = algebra::multi(tmp1, H);
//	delete tmp1;
//
//	tmp1 = algebra::add(C, D);
//	p3 = algebra::multi(tmp1, E);
//	delete tmp1;
//
//	tmp1 = algebra::minus(G, E);
//	p4 = algebra::multi(D,tmp1);
//	delete tmp1;
//
//	tmp1 = algebra::add(A, D);
//	tmp2 = algebra::add(E, H);
//	p5 = algebra::multi(tmp1, tmp2);
//	delete tmp1;
//	delete tmp2;
//
//	tmp1 = algebra::minus(B, D);
//	tmp2 = algebra::add(G, H);
//	p6 = algebra::multi(tmp1, tmp2);
//	delete tmp1;
//	delete tmp2;
//
//	tmp1 = algebra::minus(A, C);
//	tmp2 = algebra::add(E, F);
//	p7 = algebra::multi(tmp1, tmp2);
//	delete tmp1;
//	delete tmp2;
//
//	delete A;
//	delete B;
//	delete C;
//	delete D;
//	delete E;
//	delete F;
//	delete G;
//	delete H;
//
//	matric2D * C11, * C12, * C21, * C22;
//
//	tmp1 = algebra::add(p5, p4);
//	tmp2 = algebra::minus(tmp1, p2);
//	delete tmp1;
//	C11 = algebra::add(tmp2, p6);
//	delete tmp2;
//
//	C12 = algebra::add(p1, p2);
//	C21 = algebra::add(p3, p4);
//
//	tmp1 = algebra::add(p1, p5);
//	tmp2 = algebra::minus(tmp1, p3);
//	delete tmp1;
//	C22 = algebra::minus(tmp2, p7);
//	delete tmp2;
//
//	delete p1;
//	delete p2;
//	delete p3;
//	delete p4;
//	delete p5;
//	delete p6;
//	delete p7;
//
//	
//	matric2D * pC = new matric2D(pA->x_max, pB->y_max);
//	int x_begin = ax / 2;
//	int y_begin = by / 2;
//
//	int core = omp_get_num_procs();
//	#pragma omp parallel for num_threads(core)
//	for (int i = 0; i < C11->x_max; i++){
//		for (int j = 0; j < C11->y_max; j++){
//			pC->matric[i][j] = C11->matric[i][j];
//		}
//	}
//	#pragma omp parallel for num_threads(core)
//	for (int i = 0; i < C12->x_max; i++){
//		for (int j = 0; j < C12->y_max; j++){
//			if (y_begin+j<pC->y_max)
//				pC->matric[i][y_begin + j] = C12->matric[i][j];
//		}
//	}
//	#pragma omp parallel for num_threads(core)
//	for (int i = 0; i < C21->x_max; i++){
//		for (int j = 0; j < C21->y_max; j++){
//			if (x_begin+i<pC->x_max)
//				pC->matric[i + x_begin][j] = C21->matric[i][j];
//		}
//	}
//	#pragma omp parallel for num_threads(core)
//	for (int i = 0; i < C22->x_max; i++){
//		for (int j = 0; j < C22->y_max; j++){
//			if (x_begin + i<pC->x_max && y_begin + j<pC->y_max)
//				pC->matric[x_begin + i][y_begin + j] = C22->matric[i][j];
//		}
//	}
//
//	delete C11;
//	delete C12;
//	delete C21;
//	delete C22;
//
//	return pC;
	//if (pA->y_max != pB->x_max){
	//	cout << "������������һ!�޷���ˣ�\tA:" << pA->x_max << "x" << pA->y_max << "\tB:" << pB->x_max << "x" << pB->y_max << endl;
	//	return NULL;
	//}
	//matric2D * pm = new matric2D(pA->x_max, pB->y_max);
	//
	//int iT, jT, kT;;
	//iT = find(pA->x_max);
	//jT = find(pB->y_max);
	//kT = find(pA->y_max);

	//int it, jt, kt, i, j, k;

	//for (it = 0; it < pA->x_max; it += iT){
	//	for (jt = 0; jt < pB->y_max; jt += jT){
	//		for (kt = 0; kt < pA->y_max; kt += kT){
	//			//int core = omp_get_num_procs();
	//			//#pragma omp parallel for num_threads(core)
	//			for (i = it; i < it + iT; i++){
	//				for (j = jt; j < jt + jT; j++){
	//					for (k = kt; k < kt + kT; k++)
	//						if (pA->get(i, k) != 0 && pB->get(k, j) != 0)
	//							pm->set(i, j, pm->get(i, j) + pA->get(i, k)*pB->get(k, j));
	//				}
	//			}
	//		}
	//	}
	//}
	//return pm;
//}