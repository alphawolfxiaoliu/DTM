#include"matric1D.h"
#include"matric2D.h"
#include<fstream>

#include<iostream>
#include<string>

#pragma once

#ifndef _MIO_UTILS_H_
#define _MIO_UTILS_H_

using namespace std;

void saveFileDense(matric2D * pU, string fileName);
void saveFileSparse(matric2D * pU, string fileName);
matric2D * readFileSparse(string fileName);
matric2D * readFileDense(string fileName);

#endif