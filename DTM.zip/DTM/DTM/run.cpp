#include"algebra.h"
#include"uvde.h"
#include"mioutils.h"
#include"statisticsutils.h"
#include<iostream>
#include<fstream>
#include<string>
#include<cstdio>
#include<map>
#include<list>

// These two header files are intended to creat a new directory dynamicly.
#include<io.h>
#include<direct.h>

using namespace std;

void test1(){
	uv_decompose * de = new uv_decompose(60, 30, 15);
	de->k1 = 10;
	de->k2 = 5;
	de->s = 0.01;
	de->pPreU = new matric2D(60, de->k1);
	de->pD->random_init(true);
	de->pPreU->random_init(true);
	de->lambda = 0.1;
	de->epsilon = 0.3;
	de->eta = 0.00;
	de->d_loop_max = 100;
	de->u_loop_max = 100;
	de->v_loop_max = 100;
	de->u_eps = 1e-4;
	de->v_eps = 1e-4;

	getchar();

	saveFileDense(de->pPreU, "test/PreU.txt");

	float lamdas[] = { 0.1 };
	float epsilons[] = { 0.7 };
	float etas[] = { 10, 1, 0.1 };

	for (int i = 0; i <= 0; i++){
		for (int j = 0; j <= 3; j++){
			for (int k = 0; k <= 0; k++){
				char filename[1000];
				sprintf(filename, "test/%lf", etas[j]);
				string strfname(filename);
				de->lambda = lamdas[k];
				de->epsilon = epsilons[i];
				de->eta = etas[j];

				de->pU->random_init(true);
				de->pV->random_init(true);
				de->decompose();
				saveFileDense(de->pU, strfname + "-U.txt");
				saveFileDense(de->pV, strfname + "-V.dat");
				getchar();
			}
		}
	}
	cout << "Done" << endl;
}
/*
TDT
*/
void main(){
	//test();
	//ʱ�����е��ĵ�����
	//string datafiles[] = {
	//	"LHUI/TFIDF+LHUI+2008.txt",
	//	"LHUI/TFIDF+LHUI+2009.txt",
	//	"LHUI/TFIDF+LHUI+2010.txt",
	//	"LHUI/TFIDF+LHUI+2011.txt",
	//	"LHUI/TFIDF+LHUI+2012.txt",
	//	"LHUI/TFIDF+LHUI+2013.txt",
	//	"LHUI/TFIDF+LHUI+2014.txt"
	//};
	//int fileSize = 7;
	/*string datafiles[] = {
	"LHUI/TFIDF+2015-03-01.txt",
	"LHUI/TFIDF+2015-03-02.txt",
	"LHUI/TFIDF+2015-03-03.txt",
	"LHUI/TFIDF+2015-03-04.txt",
	"LHUI/TFIDF+2015-03-05.txt",
	"LHUI/TFIDF+2015-03-06.txt",
	"LHUI/TFIDF+2015-03-07.txt",
	"LHUI/TFIDF+2015-03-08.txt",
	"LHUI/TFIDF+2015-03-09.txt",
	"LHUI/TFIDF+2015-03-10.txt",
	"LHUI/TFIDF+2015-03-11.txt",
	"LHUI/TFIDF+2015-03-12.txt",
	"LHUI/TFIDF+2015-03-13.txt",
	"LHUI/TFIDF+2015-03-14.txt",
	"LHUI/TFIDF+2015-03-15.txt"
	};
	int fileSize = 15;*/
	int fileSize = 10;
	//int fileSize = 35;
	//string datafiles[] = {
	//	"SouGouDTM/TFIDF+SOUGOU+1th.txt",
	//	"SouGouDTM/TFIDF+SOUGOU+2th.txt",
	//	"SouGouDTM/TFIDF+SOUGOU+3th.txt",
	//	"SouGouDTM/TFIDF+SOUGOU+4th.txt",
	//	"SouGouDTM/TFIDF+SOUGOU+5th.txt",
	//	"SouGouDTM/TFIDF+SOUGOU+6th.txt",
	//	"SouGouDTM/TFIDF+SOUGOU+7th.txt",
	//	"SouGouDTM/TFIDF+SOUGOU+8th.txt",
	//	"SouGouDTM/TFIDF+SOUGOU+9th.txt",
	//	"SouGouDTM/TFIDF+SOUGOU+10th.txt"
	//};
	//�ѹ�����ֲ�������
	//string datafiles[] = {
	//	"SouGouDTMRanNoFad/TFIDF+SOUGOU+RANDOM+1th.txt",
	//	"SouGouDTMRanNoFad/TFIDF+SOUGOU+RANDOM+2th.txt",
	//	"SouGouDTMRanNoFad/TFIDF+SOUGOU+RANDOM+3th.txt",
	//	"SouGouDTMRanNoFad/TFIDF+SOUGOU+RANDOM+4th.txt",
	//	"SouGouDTMRanNoFad/TFIDF+SOUGOU+RANDOM+5th.txt",
	//	"SouGouDTMRanNoFad/TFIDF+SOUGOU+RANDOM+6th.txt",
	//	"SouGouDTMRanNoFad/TFIDF+SOUGOU+RANDOM+7th.txt",
	//	"SouGouDTMRanNoFad/TFIDF+SOUGOU+RANDOM+8th.txt",
	//	"SouGouDTMRanNoFad/TFIDF+SOUGOU+RANDOM+9th.txt",
	//	"SouGouDTMRanNoFad/TFIDF+SOUGOU+RANDOM+10th.txt"
	//};
	//string datafiles[] = {
	//	"20NewsDTMRan/TFIDF+20NEWS+RANDOM+1th.txt",
	//	"20NewsDTMRan/TFIDF+20NEWS+RANDOM+2th.txt",
	//	"20NewsDTMRan/TFIDF+20NEWS+RANDOM+3th.txt",
	//	"20NewsDTMRan/TFIDF+20NEWS+RANDOM+4th.txt",
	//	"20NewsDTMRan/TFIDF+20NEWS+RANDOM+5th.txt",
	//	"20NewsDTMRan/TFIDF+20NEWS+RANDOM+6th.txt",
	//	"20NewsDTMRan/TFIDF+20NEWS+RANDOM+7th.txt",
	//	"20NewsDTMRan/TFIDF+20NEWS+RANDOM+8th.txt",
	//	"20NewsDTMRan/TFIDF+20NEWS+RANDOM+9th.txt",
	//	"20NewsDTMRan/TFIDF+20NEWS+RANDOM+10th.txt"
	//};

	//string datafiles[] = {
	//	"20NewsDTMRanSecond/TFIDF+20NEWS+RANDOM-ANOTHER+1th.txt",
	//	"20NewsDTMRanSecond/TFIDF+20NEWS+RANDOM-ANOTHER+2th.txt",
	//	"20NewsDTMRanSecond/TFIDF+20NEWS+RANDOM-ANOTHER+3th.txt",
	//	"20NewsDTMRanSecond/TFIDF+20NEWS+RANDOM-ANOTHER+4th.txt",
	//	"20NewsDTMRanSecond/TFIDF+20NEWS+RANDOM-ANOTHER+5th.txt",
	//	"20NewsDTMRanSecond/TFIDF+20NEWS+RANDOM-ANOTHER+6th.txt",
	//	"20NewsDTMRanSecond/TFIDF+20NEWS+RANDOM-ANOTHER+7th.txt",
	//	"20NewsDTMRanSecond/TFIDF+20NEWS+RANDOM-ANOTHER+8th.txt",
	//	"20NewsDTMRanSecond/TFIDF+20NEWS+RANDOM-ANOTHER+9th.txt",
	//	"20NewsDTMRanSecond/TFIDF+20NEWS+RANDOM-ANOTHER+10th.txt"
	//}; 

	string datafiles[] = {
			"20News/TFIDF+20NEWS+1th.txt",
			"20News/TFIDF+20NEWS+2th.txt",
			"20News/TFIDF+20NEWS+3th.txt",
			"20News/TFIDF+20NEWS+4th.txt",
			"20News/TFIDF+20NEWS+5th.txt",
			"20News/TFIDF+20NEWS+6th.txt",
			"20News/TFIDF+20NEWS+7th.txt",
			"20News/TFIDF+20NEWS+8th.txt",
			"20News/TFIDF+20NEWS+9th.txt",
			"20News/TFIDF+20NEWS+10th.txt"
	};


	//string datafiles[] = {
	//	"SinaWeiboDTM-ALPHA/series-1-part.txt",
	//	"SinaWeiboDTM-ALPHA/series-2-part.txt",
	//	"SinaWeiboDTM-ALPHA/series-3-part.txt",
	//	"SinaWeiboDTM-ALPHA/series-4-part.txt",
	//	"SinaWeiboDTM-ALPHA/series-5-part.txt",
	//	"SinaWeiboDTM-ALPHA/series-6-part.txt",
	//	"SinaWeiboDTM-ALPHA/series-7-part.txt",
	//	"SinaWeiboDTM-ALPHA/series-8-part.txt",
	//	"SinaWeiboDTM-ALPHA/series-9-part.txt",
	//	"SinaWeiboDTM-ALPHA/series-10-part.txt",
	//	"SinaWeiboDTM-ALPHA/series-11-part.txt",
	//	"SinaWeiboDTM-ALPHA/series-12-part.txt",
	//	"SinaWeiboDTM-ALPHA/series-13-part.txt",
	//	"SinaWeiboDTM-ALPHA/series-14-part.txt"
	//};


	//paramenters begin
	double lamdas[] = {
		0.0,
		0.0,
		0.01,
		0.1
	};
	double elpsions[] = {
		0.0,
		1.0,
		0.0,
		 0.7 //orthogonal on U
		 //0.005 // sparse on U
	};
	double holds[] = {
		0.0,
		0.0,
		0.0,
		 0.05
		 // 0.02
		//0.08
	};
	//paramenters end


	//step begin
	int Ks[] = {
		//0, 0, 20, 20
		//80
		//60
		8
		//20
	};
	int Adds[] = {
		//8, 8, 6, 6
		//15
		// 10
		  8
		  //5
	};
	double etas[] = {
		10.0,
		1.0,
		10.0,
		1.0
	};
	//step end
	//string dir = "SinaWeiboDTM/Result/";
	//string dir = "SinaWeiboDTM-xiaoliu/Result/";
	//string dir = "SouGouDTM/ResultSparse/";
	//string dir = "SinaWeiboDTM-ALPHA/Result/";

	string dir = "20News/Result/";

	for (int parameter = 3; parameter < 4; parameter++){
		//��ʧ������������ֵ
		float threshold = holds[parameter];
		double lamda = lamdas[parameter];
		double epsilon = elpsions[parameter];

		for (int step = 0; step < 1; step++){
			map<int, int> topicIndex;
			int topicCount = 0;
			matric2D * pPreU = NULL, *pV = NULL;
			//��ʼ���⣨k+add���Լ�ÿ�����ӵ�������
			int K = Ks[step];
			int add = Adds[step];
			double eta = etas[step];
			
			char  savefile[200];
			cout << "In Paramenter " << parameter << endl;
			cout << "In Step " << step << endl;
			cout << "K:" << K << endl;
			cout << "Add:" << add << endl;
			cout << "Eta:" << eta << endl;
			cout << "Hold:" << threshold << endl;
			cout << "Lamda:" << lamda << endl;
			cout << "Epsilon:" << epsilon << endl;

			for (int l = 0; l < fileSize; l++){
				cout << "In File " << l << endl;
				matric2D * pData = readFileSparse(datafiles[l]);

				cout << "*********************" <<datafiles[l] << endl;

				if (pPreU == NULL){
					K = K + add;
				}
				else{
					K = pPreU->y_max + add;
				}
				uv_decompose * pde = new uv_decompose(pData->matric, pData->x_max, pData->y_max, K);
				//����
				//����Ĳ���pde->s = 0.0001;
				pde->s = 0.02;
				pde->lambda = lamda;
				pde->epsilon = epsilon;
				pde->d_loop_max = 50;
				pde->u_loop_max = 100;
				pde->v_loop_max = 100;
				pde->u_eps = 5e-5;
				pde->v_eps = 5e-5;
				//������м���
				pde->saveIter = 200;

				char tempDir[200];
				// Here dynamicly creat Directory to load corresponding results of different configurations
				sprintf(tempDir, "%sl=%.2lf,e=%.1lf,eta=%d,add=%d", dir.c_str(),lamda, epsilon, (int)eta, add);
				if (_access(tempDir, 6) == -1){
					_mkdir(tempDir);
					cout << "FILE DIRECTORY:" << tempDir << " has been successfully created..." << endl;
				}
				else
				{
					cout << "FILE DIRECTORY:" << tempDir << " has already existed..." << endl;
				}
				// ////////////////////////////////////////////////////////////////////////////////////////


				sprintf(savefile, "l=%.2lf,e=%.1lf,eta=%d,add=%d/run.log", lamda, epsilon, (int)eta, add);
					
				pde->log_file_name = dir+savefile;

				pde->pU->random_init(true);
				pde->pV->random_init(true);

				cout << "File" << "***" <<dir + savefile << endl;

				//����ǰ����U���趨����k1,k2,pPreU�Լ�eta
				//�����ӵ�����ı��
				map<int, int> newTopic;
				if (pPreU != NULL){
					for (int i = pPreU->y_max; i < K; i++){
						topicIndex[i] = topicCount;
						newTopic[topicCount] = 1;
						topicCount++;
					}
					pde->k1 = pPreU->y_max;
					pde->k2 = K - pPreU->y_max;
					pde->pPreU = pPreU;
					pde->eta = eta;
				}
				else{
					for (int i = 0; i < K; i++){
						topicIndex[i] = i;
						newTopic[topicCount++] = 1;
					}
					topicCount = K;
				}

				cout << "Start Decompositions ..." << endl;
				pde->decompose();
				//���ֽ�õ���pU��ֵ��pPreU
				pPreU = pde->pU->get_copy();
				//�������������ֵ����ʼѰ����Ҫfadding������
				//��������Ȩ��
				double * value = new double[pde->pV->x_max];
				int * uzero = new int[pde->pV->x_max];

				double max = 0.0;
				for (int i = 0; i < pde->pV->x_max; i++){
					matric1D * pR = pde->pV->get_row(i);
					uzero[i] = 0;
					value[i] = average(pR);
					if (max < value[i]){
						max = value[i];
					}
					for (int r = 0; r < pR->x_max; r++){
						if (pR->matric[r] != 0.0){
							uzero[i]++;
						}
					}
					delete pR;
				}
				//��¼��ʧ��������
				int faddingCount = 0;
				//��¼��������״̬�仯
				sprintf(savefile, "l=%.2lf,e=%.1lf,eta=%d,add=%d/TopicTable.txt", lamda, epsilon, (int)eta, add);
				ofstream out(dir + savefile, ofstream::app);
				out << "The " << (l) << "th" << endl;
				//��ǰU�����е�����ı仯״̬
				map<int, string> topicInfo;
				for (int i = 0; i < pPreU->y_max; i++){
					value[i] = value[i] / max;
					//��õ�ǰ�����ʵ�ʱ��
					int topicNum = topicIndex[i];
					char cvalue[300];
					double uz = uzero[i];
					if (value[i] < threshold){
						sprintf(cvalue, "Topic \t%d(%d):\t\tFadding \t%.5lf\t\t%.5lf\t\t%d/%d\t\t%.5lf", i, topicNum, value[i] * max, value[i], uzero[i], pde->pV->y_max, uz / pde->pV->y_max);
						faddingCount++;
						if (newTopic.find(topicNum) != newTopic.end()){
							sprintf(cvalue, "Topic \t%d(%d):\t\tEm&Fding\t%.5lf\t\t%.5lf\t\t%d/%d\t\t%.5lf", i, topicNum, value[i] * max, value[i], uzero[i], pde->pV->y_max, uz / pde->pV->y_max);
						}
					}
					else{
						if (newTopic.find(topicNum) != newTopic.end()){
							sprintf(cvalue, "Topic \t%d(%d):\t\tEmerging\t%.5lf\t\t%.5lf\t\t%d/%d\t\t%.5lf", i, topicNum, value[i] * max, value[i], uzero[i], pde->pV->y_max, uz / pde->pV->y_max);
						}
						else{
							sprintf(cvalue, "Topic \t%d(%d):\t\tEvolving\t%.5lf\t\t%.5lf\t\t%d/%d\t\t%.5lf", i, topicNum, value[i] * max, value[i], uzero[i], pde->pV->y_max, uz / pde->pV->y_max);
						}
					}
					topicInfo[topicNum] = cvalue;
				}
				//������ļ�
				out << "Topic Num(RealNum)\tStatus\t\tValue\t\tRatio\t\tnot Zeros\tnot-z Ratio" << endl;
				for (int i = 0; i < topicCount; i++){
					if (topicInfo.find(i) != topicInfo.end()){
						out << topicInfo[i] << "\t" << endl;
					}
					else{
						//out << "Topic "<<-1<<"("<<i<<"):\tNone\tNone" << endl;
					}
				}
				out << endl << endl;
				out.close();
				//����preU����
				int remove = 0;
				map<int, int> tmptopics;
				//fadding U���¼����ʱʹ�õ���fadding���U
				matric2D * pU = new matric2D(pPreU->x_max, pPreU->y_max - faddingCount);
				for (int c = 0; c < pPreU->y_max; c++){
					if (value[c] >= threshold){
						tmptopics[c - remove] = topicIndex[c];
						for (int r = 0; r < pU->x_max; r++){
							pU->matric[r][c - remove] = pPreU->matric[r][c];
						}
					}
					else{
						remove++;
					}
				}
				//fadding V���¼����ʱʹ�õ���fadding���V
				remove = 0;
				matric2D * pV = new matric2D(pPreU->y_max - faddingCount, pde->pV->y_max);
				for (int r = 0; r < pPreU->y_max; r++){
					if (value[r] >= threshold){
						for (int c = 0; c < pV->y_max; c++){
							pV->matric[r - remove][c] = pde->pV->matric[r][c];
						}
					}
					else{
						remove++;
					}
				}

				sprintf(savefile, "l=%.2lf,e=%.1lf,eta=%d,add=%d/�����ݻ��ſ�.txt", lamda, epsilon, (int)eta, add);
				ofstream out1(dir + savefile, ofstream::app);
				out1 << l << "th:   TDT  last:" << pPreU->y_max - add << "\tadd:" << add << "\tcurrent:" << pPreU->y_max << "\tfadding:" << faddingCount << "\tleft:" << pU->y_max << endl;
				out1.close();



				//ʵ�������Ӧ
				topicIndex = tmptopics;
				//���
				sprintf(savefile, "l=%.2lf,e=%.1lf,eta=%d,add=%d/U%d.txt", lamda, epsilon, (int)eta, add, l);
				saveFileSparse(pde->pU, dir + savefile);
				sprintf(savefile, "l=%.2lf,e=%.1lf,eta=%d,add=%d/V%d.txt", lamda, epsilon, (int)eta, add, l);
				saveFileSparse(pde->pV, dir + savefile);
				sprintf(savefile, "l=%.2lf,e=%.1lf,eta=%d,add=%d/FU%d.txt", lamda, epsilon, (int)eta, add, l);
				saveFileSparse(pU, dir + savefile);
				sprintf(savefile, "l=%.2lf,e=%.1lf,eta=%d,add=%d/FV%d.txt", lamda, epsilon, (int)eta, add, l);
				saveFileSparse(pV, dir + savefile);

				delete pPreU;
				delete pData;
				delete pde;
				delete pV;
				delete value;
				delete uzero;

				pPreU = pU;
			}
		}
	}
}