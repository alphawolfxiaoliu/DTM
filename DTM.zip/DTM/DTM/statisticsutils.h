#include<iostream>
#include<string>
#include"matric1D.h"
#include"matric2D.h"

using namespace std;

#pragma once

#ifndef STATISTICS_UTILS
#define STATISTICS_UTILS

double average(matric1D * pD);
double average(matric2D * pD);
double variance(matric1D * pD);
double variance(matric2D * pD);

#endif