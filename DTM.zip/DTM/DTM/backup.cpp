//#include"uvde.h"
//#include"mioutils.h"
//
//uv_decompose::uv_decompose(int m, int n, int k){
//	this->m = m;
//	this->n = n;
//	this->k = k;
//
//	//this->pD = new matric2D(this->m,this->n);
//	this->pU = new matric2D(this->m, this->k);
//	this->pV = new matric2D(this->k, this->n);
//	this->pD = new matric2D(this->m, this->n);
//	this->pPreU = NULL;
//
//	this->u_eps = 1e-8;
//	this->v_eps = 1e-8;
//
//	this->u_loop_max = 1000;
//	this->v_loop_max = 1000;
//	this->d_loop_max = 500;
//
//	this->k1 = 0;
//	this->k2 = 0;
//
//	this->epsilon = 0;
//	this->lambda = 0;
//	this->eta = 0;
//	this->s = 0.01;
//	this->log_file_name = "result";
//}
//
//uv_decompose::uv_decompose(double ** data, int m, int n, int k){
//	this->m = m;
//	this->n = n;
//	this->k = k;
//
//	//this->pD = new matric2D(this->m,this->n);
//	this->pU = new matric2D(this->m, this->k);
//	this->pV = new matric2D(this->k, this->n);
//	this->pD = new matric2D(this->m, this->n);
//	this->pPreU = NULL;
//
//	for (int i = 0; i<this->m; ++i){
//		for (int j = 0; j<this->n; ++j){
//			this->pD->set(i, j, data[i][j]);
//		}
//	}
//	this->pD->normalization();
//	this->u_eps = 1e-8;
//	this->v_eps = 1e-8;
//
//	this->u_loop_max = 1000;
//	this->v_loop_max = 1000;
//	this->d_loop_max = 500;
//
//	this->k1 = 0;
//	this->k2 = 0;
//
//	this->epsilon = 0;
//	this->lambda = 0;
//	this->eta = 0;
//	this->s = 0.01;
//	this->log_file_name = "result";
//}
//
//uv_decompose::uv_decompose(struct uint * data, int length, int m, int n, int k){
//	this->m = m;
//	this->n = n;
//	this->k = k;
//
//	this->pU = new matric2D(this->m, this->k);
//	this->pV = new matric2D(this->k, this->n);
//	this->pD = new matric2D(this->m, this->n);
//	this->pPreU = NULL;
//
//	for (int i = 0; i < length; i++){
//		this->pD->set(data[i].x, data[i].y, data[i].value);
//	}
//
//	this->pD->normalization();
//	this->u_eps = 1e-8;
//	this->v_eps = 1e-8;
//
//	this->u_loop_max = 1000;
//	this->v_loop_max = 1000;
//	this->d_loop_max = 500;
//
//	this->k1 = 0;
//	this->k2 = 0;
//
//	this->epsilon = 0;
//	this->lambda = 0;
//	this->eta = 0;
//	this->s = 0.01;
//	this->log_file_name = "result";
//}
//
//uv_decompose::~uv_decompose(){
//	delete pD;
//	delete pU;
//	delete pV;
//	if (pPreU != NULL){
//		delete pPreU;
//	}
//}
//
//void uv_decompose::set_pre_u_k(struct uint * data, int length, int k1){
//	this->k1 = k1;
//	this->k2 = this->k - k1;
//
//	this->pPreU = new matric2D(this->pD->x_max, k1);
//
//	for (int i = 0; i < this->pPreU->x_max; i++){
//		for (int j = 0; j < this->pPreU->y_max; j++){
//			this->pPreU->set(i, j, 0);
//		}
//	}
//	for (int i = 0; i < length; i++){
//		this->pPreU->set(data[i].x, data[i].y, data[i].value);
//	}
//}
//
//void uv_decompose::update_u(){
//	matric2D * pVt = algebra::transpose(this->pV);
//	matric2D * pVVt = algebra::multi(this->pV, pVt);
//	matric2D * pDVt = algebra::multi(this->pD, pVt);
//
//	int lastIterTime = 1000;
//	int t = 1.0;
//	double eps;
//	do{
//		//����
//		double step = this->s;
//		//����ֽ��ݶ�
//		matric2D * pUVVt = algebra::multi(this->pU, pVVt);
//		matric2D * pUVVt_DVt = algebra::minus(pUVVt, pDVt);
//		matric2D * pGradientU = algebra::multi(pUVVt_DVt, 2.0 * step);
//		delete pUVVt;
//		delete pUVVt_DVt;
//
//		//�����ݶ�
//		if (this->epsilon != 0){
//			matric2D * pUt = algebra::transpose(this->pU);
//			matric2D * pUtU = algebra::multi(pUt, this->pU);
//			matric2D * pUtU_E = algebra::add_e(pUtU, -1.0);
//			matric2D * pUUtU_U = algebra::multi(this->pU, pUtU_E);
//			matric2D * pOrginalGra = algebra::multi(pUUtU_U, 4 * this->epsilon * step);
//			matric2D * pGraOld = pGradientU;
//			pGradientU = algebra::add(pGraOld, pOrginalGra);
//			delete pUt;
//			delete pUtU;
//			delete pUtU_E;
//			delete pUUtU_U;
//			delete pGraOld;
//			delete pOrginalGra;
//		}
//
//		//�ݻ��ݶ�
//		if (this->eta != 0){
//			for (int i = 0; i < this->m; i++){
//				for (int j = 0; j < this->k1; j++){
//					//ֱ�����ݶ��Ͻ�����������
//					pGradientU->matric[i][j] += 2 * (this->pU->matric[i][j] - this->pPreU->matric[i][j]) * this->eta;
//				}
//			}
//		}
//		//�����µ�U
//		matric2D * pU1 = algebra::minus(this->pU, pGradientU);
//		matric2D * pU_new = algebra::non_nagetive_map(pU1);
//		matric2D * pDelt = algebra::minus(pU_new, this->pU);
//		eps = algebra::norm_f(pDelt);
//		delete this->pU;
//		delete pDelt;
//		delete pU1;
//		delete pGradientU;
//
//		this->pU = pU_new;
//		t++;
//
//	} while (eps>this->u_eps&&t <= this->u_loop_max);
//
//	if (this->log_file_name.size()>0){
//		fstream out(log_file_name, fstream::app);
//		out << "update_u():" << t - 1;
//		out.close();
//	}
//	cout << "::updateU(" << t - 1 << ")  ";
//	delete pVt;
//	delete pVVt;
//	delete pDVt;
//	//cout << "update_u();";
//	//int t = 0;
//	//double eps = 1;
//	////��ʼ��
//	//matric2D * pV1, *pV2, *pV1t, *pV2t;
//	//matric2D * pDV1t, *pDV2t, *pV1V2t, *pV1V1t, *pV2V2t, *pV2V1t;
//	//algebra::devide_row(pV, pV1, pV2, this->k1, this->k2);
//	//pV1t = algebra::transpose(pV1);
//	//pV2t = algebra::transpose(pV2);
//	//pDV2t = algebra::multi(this->pD, pV2t);
//	//pDV1t = algebra::multi(this->pD, pV1t);
//	//pV1V2t = algebra::multi(pV1, pV2t);
//	//pV1V1t = algebra::multi(pV1, pV1t);
//	//pV2V2t = algebra::multi(pV2, pV2t);
//	//pV2V1t = algebra::transpose(pV1V2t);
//
//	//do{
//	//	float step = this->s;
//	//	matric2D * pOrginalGra = NULL;
//	//	matric2D * pGradientU, * pGradientUIns;
//	//	matric2D * pU1, * pUIns, * pOld;
//	//	algebra::devide_column(this->pU, pU1, pUIns, this->k1, this->k2);
//	//	
//	//	//�ݶ�1
//	//	pGradientU = gradient_1(pU1, pUIns, pDV1t, pV1V1t, pV2V1t, 2 * step);
//	//	pGradientUIns = gradient_1(pU1, pUIns, pDV2t, pV1V2t, pV2V2t, 2 * step);
//	//	//�ݶ�2,�տ�ʼʱ��pPreU��û��ֵ�ģ�����eta��Ҫ����Ϊ0
//	//	if (this->eta != 0){
//	//		matric2D * pGU2 = gradient_2(pU1, this->pPreU, 2 * this->eta * step);
//	//		pOld = pGradientU;
//	//		pGradientU = algebra::add(pGU2, pGradientU);
//	//		delete pGU2, pOld;
//	//	}
//	//	
//	//	if (this->epsilon != 0){
//	//		//�ݶ�3���ݶ�5,���㷽��һ��,ͳһ��Ϊ�ݶ�3
//	//		//matric2D * pGU3 = gradient_3(pU1, 4 * this->epsilon * step);
//	//		//pOld = pGradientU;
//	//		//pGradientU = algebra::add(pGU3, pGradientU);
//	//		//delete pGU3, pOld;
//
//	//		//matric2D * pGUins3 = gradient_3(pUIns, 4 * this->epsilon * step);
//	//		//pOld = pGradientUIns;
//	//		//pGradientUIns = algebra::add(pGUins3, pGradientUIns);
//	//		//delete pGUins3, pOld;
//	//		////�ݶ�4
//	//		//matric2D * pGU4 = gradient_4(pUIns, pU1, 4 * this->epsilon * step);
//	//		//pOld = pGradientU;
//	//		//pGradientU = algebra::add(pGU4, pGradientU);
//	//		//delete pGU4, pOld;
//
//	//		//matric2D * pGUins4 = gradient_4(pU1, pUIns, 4 * this->epsilon * step);
//	//		//pOld = pGradientUIns;
//	//		//pGradientUIns = algebra::add(pGUins4, pGradientUIns);
//	//		//delete pGUins4, pOld;
//	//		matric2D * pUt = algebra::transpose(this->pU);
//	//		matric2D * pUtU = algebra::multi(pUt, this->pU);
//	//		matric2D * pUtU_E = algebra::add_e(pUtU, -1.0);
//	//		matric2D * pUUtU_U = algebra::multi(this->pU, pUtU_E);
//	//		pOrginalGra = algebra::multi(pUUtU_U, 4 * this->epsilon * step);
//	//		delete pUt, pUtU, pUtU, pUUtU_U;
//	//	}
//	//	
//	//	
//	//	//�ݶȼ����֮��
//	//	//�����ƶ�����
//	//	/*pOld = pGradientU;
//	//	pGradientU = algebra::multi(pGradientU, this->s);
//	//	delete pOld;
//
//	//	pOld = pGradientUIns;
//	//	pGradientUIns = algebra::multi(pGradientUIns, this->s);
//	//	delete pOld;*/
//	//	
//	//	//�����µ�pU1��pUIns
//	//	matric2D * pGradient = algebra::merge_column(pGradientU, pGradientUIns);
//	//	//�������������ݶ�
//	//	if (pOrginalGra != NULL){
//	//		pOld = pGradient;
//	//		pGradient = algebra::add(pGradient, pOrginalGra);
//	//		delete pOrginalGra, pOld;
//	//	}
//	//	//�ϲ��õ��µ�pU
//	//	matric2D * pUnew = algebra::minus(this->pU, pGradient);
//	//	pOld = pUnew;
//	//	//�Ǹ�ӳ��
//	//	pUnew = algebra::non_nagetive_map(pUnew);
//	//	delete pOld;
//	//	//�������С
//	//	matric2D * pUDelt = algebra::minus(pUnew, this->pU);
//	//	eps = algebra::norm_f(pUDelt);
//
//	//	//����U
//	//	delete this->pU;
//	//	this->pU = pUnew;
//	//	delete pUDelt;
//	//	//�ͷ��������ڴ�
//	//	delete pGradientU, pGradientUIns, pU, pUIns;
//	//	t++;
//	//} while (t<this->u_loop_max&&eps>=this->u_eps);
//
//	//if (this->log_file_name.size()>0){
//	//	fstream out(log_file_name, fstream::app);
//	//	out << "update_u():" << t;
//	//	out.close();
//	//}
//	//cout << t << "\t";
//
//	//delete pV1, pV2, pV1t, pV2t;
//	//delete pDV1t, pDV2t, pV1V2t, pV1V1t, pV2V2t, pV2V1t;
//}
//void uv_decompose::update_v(){
//	cout << "  updateV(";
//	matric2D * pUt = algebra::transpose(this->pU);
//	matric2D * pS = algebra::multi(pUt, pU);
//	matric2D * pR = algebra::multi(pUt, pD);
//	delete pUt;
//
//	int t = 1;
//	//int core = omp_get_num_procs();
//	//#pragma omp parallel for num_threads(core)
//	double value = 0.0;
//	for (int i = 0; i<this->pV->y_max; ++i){
//		value += update_v_column(i, pS, pR);
//	}
//	cout << setiosflags(ios::fixed) << setprecision(2) << 1 + value / this->pV->y_max << ")";
//
//	if (this->log_file_name.size()>0){
//		fstream out(log_file_name, fstream::app);
//		out << "\tupdate_v():" << setiosflags(ios::fixed) << setprecision(5) << (1 + value / this->pV->y_max);
//		out.close();
//	}
//
//
//	delete pS;
//	delete pR;
//}
//
//int uv_decompose::update_v_column(int column, matric2D * pS, matric2D * pR){
//	matric1D * ppv = algebra::get_cloumn_vector(this->pV, column);
//	matric1D * pv = ppv->get_copy();
//
//	int t = 0;
//	for (t = 0; t<this->v_loop_max; t++){
//		//int core = omp_get_num_procs();
//		//#pragma omp parallel for num_threads(core)
//		for (int i = 0; i<pv->x_max; ++i){
//			double value = pR->get(i, column);
//			for (int l = 0; l<pv->x_max; ++l){
//				if (l != i)
//					//value -= pS->get(i, l)*pv->get(l);
//					value -= pS->matric[i][l] * pv->matric[l];
//			}
//			value -= this->lambda / 2;
//			value /= pS->get(i, i);
//			if (value>ZERO)
//				pv->matric[i] = value;
//			else
//				pv->matric[i] = 0;
//		}
//		matric1D * pdeltv = algebra::minus(ppv, pv);
//		delete ppv;
//		ppv = pv->get_copy();
//		if (algebra::norm_1(pdeltv)<this->v_eps){
//			delete pdeltv;
//			break;
//		}
//		delete pdeltv;
//	}
//	//������������Ҳ����
//
//	for (int i = 0; i<pv->x_max; ++i){
//		//this->pV->set(i, column, pv->get(i));
//		this->pV->matric[i][column] = pv->matric[i];
//	}
//	delete ppv;
//	delete pv;
//	return t;
//}
//
//void uv_decompose::decompose(){
//	//this->pU->random_init(true);
//	//this->pV->random_init(true);
//
//	for (int i = 0; i<this->d_loop_max; ++i){
//
//
//		cout << (i + 1) << ":";
//		clock_t begin = clock();
//		this->update_u();
//		this->update_v();
//		clock_t end = clock();
//		if (this->log_file_name.size()>0){
//			fstream out(log_file_name, fstream::app);
//			out << "\titeration:" << i + 1 << "\ttime:" << end - begin << "ms" << endl;
//			out.close();
//		}
//
//		if (i % this->saveIter == this->saveIter - 1){
//			cout << endl << "Saving ...";
//			char name[20];
//			sprintf(name, "_%dth", (i / 20 + 1));
//			saveFileSparse(this->pU, u_file_name + name + ".txt");
//			saveFileSparse(this->pV, v_file_name + name + ".txt");
//		}
//		//cout << "\titeration:" << i + 1 << "\ttime:" << end - begin << "ms" << endl;
//		cout << endl;
//	}
//}
//
///*
//pA = pDV1t or pDV2t
//pB = pV1V1t or pV1V2t
//pC = pV2V1t or pV2V2t
//return (-pA+pU*pB+pUins*pC)*times
//*/
//matric2D * uv_decompose::gradient_1(matric2D * pU, matric2D * pUins, matric2D * pA, matric2D * pB, matric2D * pC, double times){
//	matric2D * p1 = algebra::multi(pU, pB);
//	matric2D * p2 = algebra::multi(pUins, pC);
//	matric2D * pS1 = algebra::add(p1, p2);
//	matric2D * pS2 = algebra::minus(pS1, pA);
//	matric2D * pR = algebra::multi(pS2, times);
//	delete p1, p2, pS1, pS2;
//	return pR;
//}
///*
//return (pU-pUpre)*times
//*/
//matric2D * uv_decompose::gradient_2(matric2D * pU, matric2D * pUpre, double times){
//	matric2D * p1 = algebra::minus(pU, pUpre);
//	matric2D * pR = algebra::multi(p1, times);
//	delete p1;
//	return pR;
//}
///*
//return (pU*pUt*pU-pU)*times
//*/
//matric2D * uv_decompose::gradient_3(matric2D * pU, double times){
//	matric2D * pUt = algebra::transpose(pU);
//	matric2D * pUtU = algebra::multi(pUt, pU);
//	matric2D * pUtU_E = algebra::add_e(pUtU, -1.0);
//	matric2D * pUUtU_U = algebra::multi(pU, pUtU_E);
//	matric2D * pR = algebra::multi(pUUtU_U, times);
//	delete pUt, pUtU, pUtU_E, pUUtU_U;
//	return pR;
//}
///*
//return (pU*pUt*pUins)*times
//*/
//matric2D * uv_decompose::gradient_4(matric2D * pU, matric2D * pUins, double times){
//	matric2D * pUt = algebra::transpose(pU);
//	matric2D * pUUt = algebra::multi(pU, pUt);
//	matric2D * pUUtUins = algebra::multi(pUUt, pUins);
//	matric2D * pR = algebra::multi(pUUtUins, times);
//	delete pUt, pUUt, pUUtUins;
//	return pR;
//}