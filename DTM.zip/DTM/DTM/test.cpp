#include "test.h"

void test(){
	uv_decompose * de = new uv_decompose(20, 16, 8);
	de->k1 = 6;
	de->k2 = 2;
	de->s = 0.0001;
	de->pPreU = new matric2D(20, de->k1);
	de->pPreU->random_init(true);
	de->pU->random_init(true);
	de->pV->random_init(true);
	de->pD = algebra::multi(de->pU, de->pV);
	de->lambda = 0.1;
	de->epsilon = 0.7;
	de->eta = 0.01;
	de->d_loop_max = 200;
	de->u_loop_max = 100;
	de->v_loop_max = 100;
	de->u_eps = 1e-6;
	de->v_eps = 1e-6;

	getchar();

	saveFileDense(de->pPreU, "test/PreU.txt");

	double lamdas[] = { 0.1, 0.3, 0.5, 0.7 };
	double epsilons[] = { 0.7, 0.9 };
	double etas[] = { 0.003, 0.03, 0.3 };

	for (int i = 0; i <= 0; i++){
		for (int j = 1; j <= 1; j++){
			for (int k = 0; k <= 3; k++){
				char filename[1000];
				sprintf(filename, "test/%lf-%lf-%lf", epsilons[i], etas[j], lamdas[k]);
				string strfname(filename);

				de->epsilon = epsilons[i];
				de->eta = etas[j];
				de->log_file_name = strfname + ".log";
				de->decompose();
				saveFileDense(de->pU, strfname + "-U.txt");
				saveFileDense(de->pV, strfname + "-V.dat");
			}
		}
	}

}