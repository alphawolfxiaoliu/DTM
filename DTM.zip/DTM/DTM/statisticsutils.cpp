#include"statisticsutils.h"

double average(matric1D * pD){
	double value = 0.0;
	for (int i = 0; i < pD->x_max; i++){
		value += pD->matric[i];
	}
	return value / pD->x_max;
}

double average(matric2D * pD){
	double value = 0.0;
	for (int i = 0; i < pD->x_max; i++){
		for (int j = 0; j < pD->y_max; j++){
			value += pD->matric[i][j];
		}
	}
	return value / (pD->x_max * pD->y_max);
}

double variance(matric1D * pD){
	double avg = average(pD);
	double value = 0.0;
	for (int i = 0; i < pD->x_max; i++){
		value += pow(pD->matric[i]-avg,2);
	}
	return sqrt(value / (pD->x_max - 1));
}

double variance(matric2D * pD){
	double avg = average(pD);
	double value = 0.0;
	for (int i = 0; i < pD->x_max; i++){
		for (int j = 0; j < pD->y_max; j++){
			value += pow(pD->matric[i][j] - avg, 2);
		}
	}
	return sqrt(value / (pD->x_max*pD->y_max - 1));
}