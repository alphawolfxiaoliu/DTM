#include"mioutils.h"

void saveFileDense(matric2D * pU, string fileName){
	ofstream outfile(fileName);
	outfile << pU->x_max << endl << pU->y_max << endl;
	outfile << setiosflags(ios::fixed) << setprecision(5);
	for (int i = 0; i < pU->x_max; i++){
		for (int j = 0; j < pU->y_max; j++){
			outfile << pU->matric[i][j] << " ";
		}
		outfile << endl;
	}
	outfile.close();
}

/*
ϡ��洢һ������
*/
void saveFileSparse(matric2D * pU, string fileName){
	ofstream outfile(fileName);
	outfile << pU->x_max << endl << pU->y_max << endl;
	outfile << setiosflags(ios::fixed) << setprecision(5);
	for (int i = 0; i < pU->x_max; i++){
		for (int j = 0; j < pU->y_max; j++){
			if (pU->matric[i][j] != 0)
				outfile << i << " " << j << " " << pU->matric[i][j] << endl;
		}
	}
	outfile.close();
}

matric2D * readFileSparse(string fileName){
	ifstream in(fileName);
	if (!in){
		cout << fileName;
		cout << "������" << endl;
		return NULL;
	}
	int m, n;
	in >> m >> n;
	matric2D * pD = new matric2D(m, n);

	while (!in.eof()){
		int x, y;
		float value;
		in >> x >> y >> value;
		pD->matric[x][y] = value;
	}
	return pD;
}

matric2D * readFileDense(string fileName){
	ifstream in(fileName);
	if (!in){
		cout << fileName;
		cout << "������" << endl;
		return NULL;
	}
	int m, n;
	in >> m >> n;
	matric2D * pD = new matric2D(m, n);
	for (int i = 0; i < m; i++){
		for (int j = 0; j < n; j++){
			in >> pD->matric[i][j];
		}
	}
	return pD;
}