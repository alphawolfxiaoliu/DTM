#include"uvde.h"
#include"mioutils.h"
#include "math.h"

uv_decompose::uv_decompose(int m, int n, int k){
	this->m = m;
	this->n = n;
	this->k = k;

	//this->pD = new matric2D(this->m,this->n);
	this->pU = new matric2D(this->m, this->k);
	this->pV = new matric2D(this->k, this->n);
	this->pD = new matric2D(this->m, this->n);
	this->pPreU = NULL;

	this->u_eps = 1e-8;
	this->v_eps = 1e-8;

	this->u_loop_max = 1000;
	this->v_loop_max = 1000;
	this->d_loop_max = 500;

	this->k1 = 0;
	this->k2 = 0;

	this->epsilon = 0;
	this->lambda = 0;
	this->eta = 0;
	this->s = 0.01;
	this->log_file_name = "result";
}

uv_decompose::uv_decompose(double ** data, int m, int n, int k){
	this->m = m;
	this->n = n;
	this->k = k;

	//this->pD = new matric2D(this->m,this->n);
	this->pU = new matric2D(this->m, this->k);
	this->pV = new matric2D(this->k, this->n);
	this->pD = new matric2D(this->m, this->n);
	this->pPreU = NULL;

	for (int i = 0; i<this->m; ++i){
		for (int j = 0; j<this->n; ++j){
			this->pD->set(i, j, data[i][j]);
		}
	}
	this->pD->normalization();
	this->u_eps = 1e-8;
	this->v_eps = 1e-8;

	this->u_loop_max = 1000;
	this->v_loop_max = 1000;
	this->d_loop_max = 500;

	this->k1 = 0;
	this->k2 = 0;

	this->epsilon = 0;
	this->lambda = 0;
	this->eta = 0;
	this->s = 0.01;
	this->log_file_name = "result";
}

uv_decompose::uv_decompose(struct uint * data, int length, int m, int n, int k){
	this->m = m;
	this->n = n;
	this->k = k;

	this->pU = new matric2D(this->m, this->k);
	this->pV = new matric2D(this->k, this->n);
	this->pD = new matric2D(this->m, this->n);
	this->pPreU = NULL;

	for (int i = 0; i < length; i++){
		this->pD->set(data[i].x, data[i].y, data[i].value);
	}

	this->pD->normalization();
	this->u_eps = 1e-8;
	this->v_eps = 1e-8;

	this->u_loop_max = 1000;
	this->v_loop_max = 1000;
	this->d_loop_max = 500;

	this->k1 = 0;
	this->k2 = 0;

	this->epsilon = 0;
	this->lambda = 0;
	this->eta = 0;
	this->s = 0.01;
	this->log_file_name = "result";
}

uv_decompose::~uv_decompose(){
	delete pD;
	delete pU;
	delete pV;
	if (pPreU != NULL){
		delete pPreU;
	}
}

void uv_decompose::set_pre_u_k(struct uint * data, int length, int k1){
	this->k1 = k1;
	this->k2 = this->k - k1;

	this->pPreU = new matric2D(this->pD->x_max, k1);

	for (int i = 0; i < this->pPreU->x_max; i++){
		for (int j = 0; j < this->pPreU->y_max; j++){
			this->pPreU->set(i, j, 0);
		}
	}
	for (int i = 0; i < length; i++){
		this->pPreU->set(data[i].x, data[i].y, data[i].value);
	}
}

//
void uv_decompose::update_uSparse(){
	matric2D * Vt = algebra::transpose(this->pV);
	// S=V*V';
	matric2D * S = algebra::multi(this->pV, Vt);
	// R=D*V';
	matric2D * R = algebra::multi(this->pD, Vt);

	this->pU->random_init(true);

	//
	double eps = 1.0;
	int iter = 0;
	//cout << "update_uSparse():";
	while (iter<this->u_loop_max && eps>this->u_eps)
	{
		//
		matric2D * U_old = this->pU->get_copy();

		// iterate each column of U matrix to upadate U
		for (size_t k = 0; k < this->pU->y_max; k++)
		{
			// ����SIGMA���� U*j-Sjk
			matric1D * tempVec = new matric1D(this->pU->x_max);
			for (size_t j = 0; j < this->pU->y_max; j++)
			{
				// ��ȥ��k�У�Ȼ����U���������е�������Ϻͣ�����ϡ��ΪS��k�г�ȥ��k��Ԫ�ص�����
				if (j!=k)
				{
					matric1D * UjColumn = this->pU->get_column(j);
					for (size_t index = 0; index < this->pU->x_max; index++)
					{
						UjColumn->set(index, UjColumn->get(index)*S->get(j,k));
					}

					//
					matric1D * tmp = algebra::add(tempVec, UjColumn);
					delete tempVec;
					tempVec = tmp;

					//
					// tempVec = algebra::add(tempVec, UjColumn);

					delete UjColumn;
					//delete tmp;
				}
			}


			// ����ÿ��
			for (size_t j = 0; j < this->pU->x_max; j++)
			{
				double tempDouble = R->get(j, k) - tempVec->get(j) - 0.5*this->epsilon;
				if (tempDouble>0)
				{
					this->pU->set(j, k, tempDouble/S->get(k,k));
				}
				else
				{
					this->pU->set(j, k, 0);

					// replaced by dropout technology
					//if (rand()*1.0 / RAND_MAX<0.5){
					//	this->pU->set(j, k, 0);
					//}
					//else
					//{
					//	this->pU->set(j, k, rand()*0.1 / RAND_MAX);
					//}
					
				}
				
			}

			//
			delete tempVec;
			
		}

		//
		iter = iter + 1;
		
		//
		matric2D * mtemp = algebra::minus(this->pU, U_old);

		eps = algebra::norm_1(mtemp);
	   // cout << "iter:" << iter << "-"<<eps<<endl;
		delete mtemp;
		delete U_old;
		// cout << "::updateU(" << iter << ")  ";
	}

	if (this->log_file_name.size()>0){
		fstream out(log_file_name, fstream::app);
		out << "update_uSparse():" << iter ;
		out.close();
	}
	cout << "::update_uSparse(" << iter  << ")  ";

	delete S;
	delete R;
	delete Vt;
	
}

void uv_decompose::update_u(){
	matric2D * pVt = algebra::transpose(this->pV);
	matric2D * pVVt = algebra::multi(this->pV, pVt);
	matric2D * pDVt = algebra::multi(this->pD, pVt);

	int lastIterTime = 1000;
	int t = 1.0;
	float eps;
	do{
		//����
		float step = this->s;
		//����ֽ��ݶ�
		matric2D * pUVVt = algebra::multi(this->pU, pVVt);
		matric2D * pUVVt_DVt = algebra::minus(pUVVt, pDVt);
		//�ݶ�ֱ�ӳ��Բ���step
		matric2D * pGradientU = algebra::multi(pUVVt_DVt, 2.0 * step);
		delete pUVVt;
		delete pUVVt_DVt;

		//�����ݶ�
		if (this->epsilon != 0){
			matric2D * pUt = algebra::transpose(this->pU);
			matric2D * pUtU = algebra::multi(pUt, this->pU);
			matric2D * pUtU_E = algebra::add_e(pUtU, -1.0);
			matric2D * pUUtU_U = algebra::multi(this->pU, pUtU_E);
			//�ݶ�ֱ�ӳ��Բ���step
			matric2D * pOrginalGra = algebra::multi(pUUtU_U, 4 * this->epsilon * step);
			matric2D * pGraOld = pGradientU;
			//�ݶȵ���
			pGradientU = algebra::add(pGraOld, pOrginalGra);
			delete pUt;
			delete pUtU;
			delete pUtU_E;
			delete pUUtU_U;
			delete pGraOld;
			delete pOrginalGra;
		}

		//�ݻ��ݶ�
		if (this->eta != 0){
			for (int i = 0; i < this->m; i++){
				for (int j = 0; j < this->k1; j++){
					//ֱ�����ݶ��Ͻ����������ɣ�ֱ�ӳ��Բ���
					pGradientU->matric[i][j] += step * 2 * (this->pU->matric[i][j] - this->pPreU->matric[i][j]) * this->eta;
				}
			}
		}
		//�����µ�U
		matric2D * pU1 = algebra::minus(this->pU, pGradientU);
		matric2D * pU_new = algebra::non_nagetive_map(pU1);
		matric2D * pDelt = algebra::minus(pU_new, this->pU);
		eps = algebra::norm_f(pDelt);
		delete this->pU;
		delete pDelt;
		delete pU1;
		delete pGradientU;

		this->pU = pU_new;
		t++;

	} while (eps>this->u_eps&&t <= this->u_loop_max);

	if (this->log_file_name.size()>0){
		fstream out(log_file_name, fstream::app);
		out << "update_u():" << t - 1;
		out.close();
	}
	cout << "::updateU(" << t - 1 << ")  ";
	delete pVt;
	delete pVVt;
	delete pDVt;
}
void uv_decompose::update_v(){
	cout << "  updateV(";
	matric2D * pUt = algebra::transpose(this->pU);
	matric2D * pS = algebra::multi(pUt, pU);
	matric2D * pR = algebra::multi(pUt, pD);
	delete pUt;

	int t = 1;
	//int core = omp_get_num_procs();
	//#pragma omp parallel for num_threads(core)
	float value = 0.0;
	for (int i = 0; i<this->pV->y_max; ++i){
		value += update_v_column(i, pS, pR);
	}
	cout << setiosflags(ios::fixed) << setprecision(2) << 1 + value / this->pV->y_max << ")";

	if (this->log_file_name.size()>0){
		fstream out(log_file_name, fstream::app);
		out << "\tupdate_v():" << setiosflags(ios::fixed) << setprecision(5) << (1 + value / this->pV->y_max);
		out.close();
	}


	delete pS;
	delete pR;
}

int uv_decompose::update_v_column(int column, matric2D * pS, matric2D * pR){
	matric1D * ppv = algebra::get_cloumn_vector(this->pV, column);
	matric1D * pv = ppv->get_copy();

	int t = 0;
	for (t = 0; t<this->v_loop_max; t++){
		//int core = omp_get_num_procs();
		//#pragma omp parallel for num_threads(core)
		for (int i = 0; i<pv->x_max; ++i){
			float value = pR->get(i, column);
			for (int l = 0; l<pv->x_max; ++l){
				if (l != i)
					//value -= pS->get(i, l)*pv->get(l);
					value -= pS->matric[i][l] * pv->matric[l];
			}
			value -= this->lambda / 2;
			value /= pS->get(i, i);
			if (value>0)
				pv->matric[i] = value;
			else
				pv->matric[i] = 0;
		}
		matric1D * pdeltv = algebra::minus(ppv, pv);
		delete ppv;
		ppv = pv->get_copy();
		if (algebra::norm_1(pdeltv)<this->v_eps){
			delete pdeltv;
			break;
		}
		delete pdeltv;
	}
	//������������Ҳ����

	for (int i = 0; i<pv->x_max; ++i){
		//this->pV->set(i, column, pv->get(i));
		this->pV->matric[i][column] = pv->matric[i];
	}
	delete ppv;
	delete pv;
	return t;
}

void uv_decompose::decompose(){
	for (int i = 0; i<this->d_loop_max; ++i){


		cout << (i + 1) << ":";
		clock_t begin = clock();
		// 
		this->update_u(); // soft orthogonal on U
		// this->update_uSparse(); // sparse on U
		this->update_v();
		clock_t end = clock();
		if (this->log_file_name.size()>0){
			fstream out(log_file_name, fstream::app);
			out << "\titeration:" << i + 1 << "\ttime:" << end - begin << "ms" << endl;
			out.close();
		}

		if (i % this->saveIter == this->saveIter - 1){
			cout << endl << "Saving ...";
			char name[20];
			sprintf(name, "_%dth", (i / 20 + 1));
			saveFileSparse(this->pU, u_file_name + name + ".txt");
			saveFileSparse(this->pV, v_file_name + name + ".txt");
		}
		//cout << "\titeration:" << i + 1 << "\ttime:" << end - begin << "ms" << endl;
		cout << endl;
	}
}